[![Discord](https://img.shields.io/discord/449576301997588490.svg?label=Discord&logo=discord)](https://discord.gg/pfQz5Pq)
[![David](https://img.shields.io/david/Gleeny/Nevrevr.svg?logo=javascript&logoColor=white)](https://david-dm.org/Gleeny/Nevrevr)
[![GitHub Issues](https://img.shields.io/github/issues/Gleeny/Nevrevr.svg?logo=github&logoColor=white)](https://github.com/Gleeny/Nevrevr/issues)
[![GitHub Last Commit](https://img.shields.io/github/last-commit/Gleeny/Nevrevr.svg?logo=github&logoColor=white)](https://github.com/Gleeny/Nevrevr/commit/master)
[![License](https://img.shields.io/github/license/Gleeny/Nevrevr.svg?label=License&logo=github&logoColor=white)](./LICENSE)

# Nevrevr

[Documentation](https://gleeny.github.io/nevrevr/) - [Support Server](https://discordapp.com/invite/JbHX5U3)

Hosted on Glitch, support me on [Patreon](https://patreon.com/gleeny) to help me move it to a new host.