[![Discord](https://img.shields.io/discord/449576301997588490.svg?label=Discord&logo=discord)](https://discord.gg/pfQz5Pq)
[![David](https://img.shields.io/david/Gleeny/Voicr.svg?logo=javascript&logoColor=white)](https://david-dm.org/Gleeny/Voicr)
[![GitHub Issues](https://img.shields.io/github/issues/Gleeny/Voicr.svg?logo=github&logoColor=white)](https://github.com/Gleeny/Voicr/issues)
[![GitHub Last Commit](https://img.shields.io/github/last-commit/Gleeny/Voicr.svg?logo=github&logoColor=white)](https://github.com/Gleeny/Voicr/commit/master)
[![License](https://img.shields.io/github/license/Gleeny/Voicr.svg?label=License&logo=github&logoColor=white)](./LICENSE)

# Voicr

[Documentation](https://gleeny.github.io/voicr/) - [Support Server](https://discordapp.com/invite/JbHX5U3)

Hosted on Glitch, support me on [Patreon](https://patreon.com/gleeny) to help me move it to a new host.
