# Different guilds' features and commands

Folders are representing the names they are most frequently known as, so small name changes won't be made to this repository. Within these folders are .js-files. All of these are individual features for the server. Within the commands-folder are commands that can be accessed inside the guild.

## Can I copy?

Yes. You can even make changes with a PR if you want, I don't really see why not. We are all a community, and if we all work together, we can make anything.