module.exports = {
  help: "",
  permissionRequired: 0,
  checkArgs: args => !args.length
};