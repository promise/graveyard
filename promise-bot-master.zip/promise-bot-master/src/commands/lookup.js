module.exports = {
  help: "<unknonw>",
  permissionRequired: 0,
  checkArgs: args => args.length == 1
};