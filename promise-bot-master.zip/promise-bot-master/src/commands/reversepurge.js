module.exports = {
  help: "<first message id> <keyword>",
  permissionRequired: 2,
  checkArgs: args => args.length == 2
};